// Nov 2026 improvements: prerendered home, legal links, screenshot tabs, plan-end rules, checklist, demo + tour, languages
const { chromium } = require('playwright');const fs=require('fs');
const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)process.exitCode=1};
const H='http://localhost:8099';
const mock=async p=>{await p.route(/fonts\.g/,r=>r.abort());
  await p.route(/vendor\/supabase-/,r=>r.fulfill({body:fs.readFileSync('mock-supabase.js','utf8'),contentType:'application/javascript'}));
  await p.route(/config\.js$/,r=>r.fulfill({body:"window.FALAK_CONFIG={supabaseUrl:'https://yourprojectref.supabase.co',supabaseAnonKey:'k',superAdmin:'falaktravelagency11@gmail.com'}",contentType:'application/javascript'}))};
(async()=>{
 const b=await chromium.launch();const errs=[];const watch=p=>{p.on('pageerror',e=>errs.push('PAGEERR '+e.message));p.on('console',m=>{if(m.type()==='error'&&/Content Security|Refused/.test(m.text()))errs.push(m.text())})};
 // ---------- 1. no JavaScript ----------
 let c=await b.newContext({javaScriptEnabled:false});let p=await c.newPage();await p.route(/fonts\.g/,r=>r.abort());
 await p.goto(H+'/');ok(/Clear books/.test(await p.locator('h1').first().innerText())&&await p.locator('.plancard').count()===3&&await p.locator('.sfaq').count()>8,'no-JS: home content, prices and FAQ visible');
 ok(await p.locator('.planrules .sterms').count()===2,'no-JS: plan-end rules visible');
 ok(await p.locator('a[href="/?demo=business"]').count()>0&&await p.locator('a[href="/?demo=travel"]').count()>0,'no-JS: both demo links');
 await p.goto(H+'/privacy');ok((await p.title()).startsWith('Privacy Policy')&&/Draft/.test(await p.locator('.slegal').innerText()),'no-JS: privacy page');
 await p.goto(H+'/terms');ok(/When a trial or paid period ends/.test(await p.locator('.slegal').innerText()),'no-JS: terms page');
 await c.close();
 // ---------- 2. with JavaScript: no wrong flash, home works ----------
 c=await b.newContext({viewport:{width:1280,height:900}});p=await c.newPage();watch(p);await mock(p);
 await p.goto(H+'/#/login');ok(await p.evaluate(()=>document.documentElement.classList.contains('nopre')),'pre copy hidden on sign-in page');
 await p.waitForTimeout(600);ok(await p.locator('#aEmail').isVisible(),'sign-in page renders');
 await p.goto(H+'/');await p.waitForTimeout(800);
 ok(!(await p.evaluate(()=>document.documentElement.classList.contains('nopre')))&&await p.locator('#authView.site #s-faq').count()===1,'home shows for visitors');
 // screenshot tabs
 const tabs=p.locator('.stab');ok(await tabs.count()===4&&await tabs.nth(0).getAttribute('aria-selected')==='true','first tab selected');
 await tabs.nth(2).click();ok(await tabs.nth(2).getAttribute('aria-selected')==='true'&&await tabs.nth(0).getAttribute('aria-selected')==='false','click selects tab');
 ok(/Travel overview/.test(await p.getAttribute('#shotImg','alt'))&&/travel\.jpg/.test(await p.getAttribute('#shotImg','src'))&&/Travel overview/.test(await p.locator('#shotCap').innerText()),'alt text and caption follow the picture');
 ok(await p.getAttribute('#shotPanel','aria-labelledby')==='stab-travel','panel labelled by selected tab');
 await tabs.nth(2).focus();await p.keyboard.press('ArrowRight');ok(await tabs.nth(3).getAttribute('aria-selected')==='true'&&await p.evaluate(()=>document.activeElement.id)==='stab-report','arrow key moves selection');
 await p.keyboard.press('Home');ok(await tabs.nth(0).getAttribute('aria-selected')==='true','Home key');
 // sign-up legal links
 await p.goto(H+'/#/signup');await p.waitForTimeout(600);
 const ln=p.locator('#legalNote a');ok(await ln.count()===2&&/\/terms$/.test(await ln.nth(0).getAttribute('href'))&&/\/privacy$/.test(await ln.nth(1).getAttribute('href')),'Terms + Privacy links beside Create account');
 const bb1=await p.locator('#af button.primary').boundingBox(),bb2=await p.locator('#legalNote').boundingBox();ok(bb2.y-bb1.y<80,'links directly under the button');
 await p.selectOption('#langAuth','tr');await p.waitForTimeout(400);ok(/Hesap oluşturmadan önce/.test(await p.locator('#legalNote').innerText()),'legal note in Turkish');
 await p.selectOption('#langAuth','fa');await p.waitForTimeout(400);ok(/لطفاً/.test(await p.locator('#legalNote').innerText()),'legal note in Dari');
 await p.selectOption('#langAuth','ps');await p.waitForTimeout(400);ok(/مهرباني/.test(await p.locator('#legalNote').innerText()),'legal note in Pashto');
 await p.selectOption('#langAuth','en');await p.waitForTimeout(300);
 await p.screenshot({path:'imp-signup.png'});
 // Dari visitor: pre copy hidden (English) until app draws Dari
 await p.evaluate(()=>localStorage.setItem('falak_lang','fa'));await p.goto(H+'/');ok(await p.evaluate(()=>document.documentElement.classList.contains('nopre')),'other language: English pre copy hidden');
 await p.waitForTimeout(700);ok(/دفاتر/.test(await p.locator('#authView h1').innerText()),'home in Dari');
 ok(/وقتی دورهٔ آزمایشی/.test(await p.locator('.planrules').innerText()),'plan rules in Dari');
 await p.evaluate(()=>localStorage.setItem('falak_lang','en'));
 await c.close();
 // ---------- 3. checklist + plan end/Free behavior (mock database) ----------
 c=await b.newContext({viewport:{width:1280,height:900}});p=await c.newPage();watch(p);await mock(p);
 await p.addInitScript(()=>sessionStorage.setItem('mockpersist','1'));
 const hash=async h=>{await p.evaluate(x=>location.hash=x,h);await p.waitForTimeout(450)};
 const auth=async(m,e)=>{await hash('#/x');await hash('#/'+m);await p.fill('#aEmail',e);await p.fill('#aPw','secret12');await p.click('#af button');await p.waitForTimeout(700)};
 const relog=async()=>{await p.reload();await p.waitForTimeout(800);await auth('login','o@x.com');await p.waitForTimeout(700)};
 await p.goto(H+'/#/login');await p.waitForTimeout(600);
 for(const e of ['staff@x.com','o@x.com'])await auth('signup',e);await auth('login','o@x.com');
 await p.click('#addBiz');await p.fill('#nbName','O Travel');await p.click('#nbBtn');await p.waitForTimeout(900);await hash('#/summary');
 ok(await p.locator('#onboard').isVisible()&&/0 \/ 5/.test(await p.locator('#onboard').innerText()),'checklist shows on a new business (0/5)');
 await p.click('[data-ob="currency"]');await p.waitForTimeout(600);ok(/1 \/ 5/.test(await p.locator('#onboard').innerText()),'base currency confirmed');
 await p.click('#onboard a[href="#/customer/new"]');await p.waitForTimeout(500);await p.fill('#fName','First Customer');await p.click('#saveBtn');await p.waitForTimeout(600);
 await hash('#/summary');ok(/2 \/ 5/.test(await p.locator('#onboard').innerText())&&await p.locator('#onboard li.next').innerText().then(t=>/opening/i.test(t)),'customer step done; next = opening balances');
 await p.click('[data-ob="noOpening"]');await p.waitForTimeout(600);ok(/3 \/ 5/.test(await p.locator('#onboard').innerText()),'new business: no opening balances');
 await p.screenshot({path:'imp-checklist.png'});
 await p.selectOption('#langSide','ps');await p.waitForTimeout(500);ok(/خپله سوداګري چمتو کړئ/.test(await p.locator('#onboard').innerText()),'checklist in Pashto');
 await p.selectOption('#langSide','en');await p.waitForTimeout(400);
 await p.click('[data-ob="hidden"]');await p.waitForTimeout(600);ok(await p.locator('#onboard').count()===0,'checklist can be hidden');
 // a ticket + a staff user during the Pro trial
 await p.evaluate(()=>{const m=JSON.parse(sessionStorage.getItem('mockdb'));const bid=m.db.businesses[0].id,cu=m.db.records.find(r=>r.type==='customer');
   m.db.records.push({id:'bk1',business_id:bid,type:'bank',data:{name:'Main bank',type:'bank',opening:0}},{id:'al1',business_id:bid,type:'supplier',data:{name:'Test Air',kind:'airline'}},{id:'tk1',business_id:bid,type:'ticket',data:{date:new Date().toISOString().slice(0,10),ref:'1',service:'ticket',passenger:'Test Pax',pnr:'ABC123',airline:'al1',route:'IST – KBL',customer:cu.id,sell:500,cost:450}});sessionStorage.setItem('mockdb',JSON.stringify(m))});
 await relog();
 await hash('#/users');await p.click('#addU');await p.fill('#mEmail','staff@x.com');await p.click('#mf button[type=submit]');await p.waitForTimeout(500);
 ok(await p.locator('tbody tr').count()===2,'staff user added during trial');
 // end the trial
 await p.evaluate(()=>{const m=JSON.parse(sessionStorage.getItem('mockdb'));m.db.subscriptions.forEach(s=>{s.trial_ends='2020-01-01T00:00:00Z'});sessionStorage.setItem('mockdb',JSON.stringify(m))});
 await relog();await hash('#/salesinvoice');
 ok(/plan has ended/i.test(await p.locator('#banner').innerText()),'expired banner');
 ok(await p.locator('a[href="#/salesinvoice/new"]').count()===0,'expired: no New buttons');
 const [dl]=await Promise.all([p.waitForEvent('download',{timeout:5000}).catch(()=>null),p.click('#csvBtn')]);ok(!!dl,'expired: export still works');
 await hash('#/reports/pl-month');ok(await p.locator('#view table').count()===1,'expired: reports work');
 await hash('#/ticket');ok(await p.locator('#view tbody tr').count()>=1&&await p.locator('a[href="#/ticket/new"]').count()===0,'expired: tickets readable, not editable');
 await hash('#/users');ok(await p.locator('#addU').isDisabled().catch(()=>true),'expired: cannot add users');
 await hash('#/billing');ok(await p.locator('.planrules').count()===1&&/view-only access/.test(await p.locator('.planrules').innerText()),'billing page explains what happens');
 // owner tries Free with 2 users → refused; remove staff → Free works
 await p.click('#goFree');await p.waitForTimeout(300);ok(/remove the other users first/i.test(await p.locator('#modal').innerText()),'Free confirm explains user rule');
 await p.click('#modal .btn.primary, #modal .btn.danger').catch(()=>{});await p.waitForTimeout(600);
 ok(/PLAN_USERS|remove the other users|1 user/i.test(await p.locator('#toast').innerText().catch(()=>'')),'Free refused while 2 users: '+(await p.locator('#toast').innerText().catch(()=>'')));
 await p.evaluate(()=>{const m=JSON.parse(sessionStorage.getItem('mockdb'));m.db.members=m.db.members.filter(x=>x.email!=='staff@x.com');sessionStorage.setItem('mockdb',JSON.stringify(m))});
 await relog();await hash('#/billing');await p.click('#goFree');await p.waitForTimeout(300);await p.click('#modal .btn.primary, #modal .btn.danger');await p.waitForTimeout(900);
 await hash('#/ticket');ok(await p.locator('#view tbody tr').count()>=1&&await p.locator('a[href="#/ticket/new"]').count()===0,'Free: tickets kept, read-only');
 await p.locator('#view tbody tr').first().click();await p.waitForTimeout(700);
 ok(await p.locator('#tkPayV').count()===1,'Free: can receive payment for a ticket');
 await p.click('#tkPayV');await p.waitForTimeout(900);await p.click('#saveBtn');await p.waitForTimeout(800);
 ok(!/PLAN_/.test(await p.locator('#toast').innerText().catch(()=>'')),'Free: ticket payment saved');
 await hash('#/salesinvoice');ok(await p.locator('a[href="#/salesinvoice/new"]').count()>=1,'Free: normal accounting works');
 await c.close();
 // ---------- 4. public demo: two starting points + tour ----------
 c=await b.newContext({viewport:{width:1280,height:900}});p=await c.newPage();watch(p);await p.route(/fonts\.g/,r=>r.abort());
 await p.goto(H+'/?demo=travel');await p.waitForTimeout(1800);
 ok(/Travel Agency/.test(await p.locator('#bizName').innerText())&&/#\/travel/.test(p.url()),'travel demo opens the travel agency on Travel overview');
 ok(await p.locator('#tour .tourpop').isVisible(),'tour starts by itself');
 const steps=[];for(let i=0;i<6;i++){steps.push(await p.locator('#tourTxt').innerText());if(i<5){await p.click('#tourNext');await p.waitForTimeout(700)}}
 ok(steps.every(Boolean)&&/Ready for your own books/.test(steps[5])&&await p.locator('#tourNext').innerText()==='Finish','6 tour steps, last = Finish');
 ok(await p.locator('.tourring').isVisible(),'highlight on last step (sign-up link)');
 await p.screenshot({path:'imp-tour.png'});
 await p.click('#tourNext');await p.waitForTimeout(300);ok(await p.locator('#tour').count()===0,'tour closes');
 await p.reload();await p.waitForTimeout(1500);ok(await p.locator('#tour').count()===0,'tour not repeated in same session');
 await p.click('#tourBtn');await p.waitForTimeout(800);ok(await p.locator('#tour').count()===1,'Take the tour button restarts it');
 await p.keyboard.press('Escape');await p.waitForTimeout(200);ok(await p.locator('#tour').count()===0,'Escape closes tour');
 await p.goto(H+'/?demo=business');await p.waitForTimeout(1800);
 ok(/Example Shop/.test(await p.locator('#bizName').innerText())&&await p.locator('#nav a[href="#/travel"]').count()===0,'small business demo: shop without travel tabs');
 ok(/Summary/.test(await p.locator('#tourTxt').innerText()),'business tour starts on Summary');
 await p.selectOption('#langSide','fa');await p.waitForTimeout(500);await p.click('#tourNext');await p.waitForTimeout(700);
 ok(/منو/.test(await p.locator('#tourTxt').innerText()),'tour in Dari');
 await p.screenshot({path:'imp-tour-fa.png'});
 await p.keyboard.press('Escape');await p.selectOption('#langSide','en');await p.waitForTimeout(300);
 const c2=await b.newContext({viewport:{width:1280,height:900}});const p2=await c2.newPage();watch(p2);await p2.route(/fonts\.g/,r=>r.abort());
 await p2.goto(H+'/?demo=1');await p2.waitForTimeout(1800);ok(await p2.locator('#demoPick').isVisible(),'plain demo link asks which demo');
 await p2.screenshot({path:'imp-demopick.png'});
 await p2.click('[data-demo="travel"]');await p2.waitForTimeout(1600);ok(/Travel Agency/.test(await p2.locator('#bizName').innerText())&&await p2.locator('#tour').count()===1,'choosing travel opens it with tour');
 // mobile tour sheet
 await p2.setViewportSize({width:390,height:800});await p2.click('#tourNext');await p2.waitForTimeout(600);
 const tb=await p2.locator('.tourpop').boundingBox();ok(tb&&tb.x>=0&&tb.x+tb.width<=391,'tour fits on a phone');
 await p2.screenshot({path:'imp-tour-mobile.png'});
 ok(!errs.length,'no page or CSP errors '+errs.join(' | '));
 await b.close();
})();
