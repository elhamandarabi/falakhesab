// Step 11: subscription payments by bank transfer — full flow in the test environment (mock database, SAMPLE bank data only)
const { chromium } = require('playwright');const fs=require('fs');
const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);if(!c)process.exitCode=1};
const PNG=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==','base64');
(async()=>{
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:1300,height:950}});const errs=[];
 p.on('pageerror',e=>errs.push('PAGEERR '+e.message));
 await p.addInitScript(()=>sessionStorage.setItem('mockpersist','1'));
 await p.route(/fonts\.g/,r=>r.abort());
 await p.route(/supabase-js|vendor\/supabase-/,r=>r.fulfill({body:fs.readFileSync('mock-supabase.js','utf8'),contentType:'application/javascript'}));
 await p.route(/config\.js$/,r=>r.fulfill({body:"window.FALAK_CONFIG={supabaseUrl:'https://x.supabase.co',supabaseAnonKey:'k',superAdmin:'falaktravelagency11@gmail.com'}",contentType:'application/javascript'}));
 const hash=async(h,ms=600)=>{await p.evaluate(x=>location.hash=x,h);await p.waitForTimeout(ms)};
 const auth=async(m,e)=>{await hash('#/x',300);await hash('#/'+m,300);await p.fill('#aEmail',e);await p.fill('#aPw','secret12');await p.click('#af button');await p.waitForTimeout(800)};
 const as=async e=>{if(await p.locator('#signOut').count()){await p.click('#signOut');await p.waitForTimeout(500)}await auth('login',e)};
 const err=s=>p.locator(s).innerText().catch(()=>'');
 const subOf=n=>p.evaluate(n=>{const d=JSON.parse(sessionStorage.getItem('mockdb')).db;const b=d.businesses.find(x=>x.name===n);return d.subscriptions.find(s=>s.business_id===b.id)},n);
 await p.goto('file://'+process.cwd()+'/site/index.html#/login');await p.waitForTimeout(700);
 for(const e of ['falaktravelagency11@gmail.com','o@x.com','ap@x.com','o2@x.com'])await auth('signup',e);
 // owner makes a business (Pro trial); other owner too
 await as('o2@x.com');await p.click('#addBiz');await p.fill('#nbName','Other Co');await p.click('#nbBtn');await p.waitForTimeout(900);
 await as('o@x.com');await p.click('#addBiz');await p.fill('#nbName','Kabul Star Travel');await p.click('#nbBtn');await p.waitForTimeout(900);
 // 1. switched off: old flow unchanged, no bank form
 await hash('#/billing',1000);ok(await p.locator('#bankPay').count()===0&&await p.locator('[data-req="pro"]').count()===1,'mode off: no bank payment form, old request flow kept');
 // 2. super admin: payment settings (test mode, SAMPLE banks)
 await as('falaktravelagency11@gmail.com');await hash('#/payments',900);
 ok(/Payment approvals/.test(await p.locator('#view h1').innerText())&&await p.locator('#sideFoot a[href="#/payments"]').count()===1,'super admin: Payment approvals page + menu link');
 await hash('#/payments/settings',900);
 await p.check('input[name=psMode][value=test]');await p.fill('#psCur','USD, TRY');await p.press('#psCur','Tab');await p.waitForTimeout(200);
 await p.fill('[data-pp="basic"][data-pc="USD"]','9');await p.fill('[data-pp="pro"][data-pc="USD"]','19');await p.fill('[data-pp="basic"][data-pc="TRY"]','299');await p.fill('[data-pp="pro"][data-pc="TRY"]','649');
 for(const [cc,st,cu] of [['TR','supported','TRY, USD'],['AF','supported','USD'],['IR','contact','']]){await p.click('#psAddCty');const r=p.locator('#psCty .ctyrow').last();await r.locator('[data-cc]').selectOption(cc);await r.locator('[data-cs]').selectOption(st);await r.locator('[data-ccur]').fill(cu)}
 await p.click('#psAddSample');await p.click('#psAddSample');await p.locator('#psBanks .bankrow').nth(1).locator('[data-bk=currency]').fill('TRY');
 await p.fill('[data-pol="fees"][data-lg="en"]','Choose "OUR" so you pay all bank fees. Fees taken by banks reduce the amount that arrives.');
 await p.fill('[data-pol="fees"][data-lg="fa"]','گزینهٔ OUR را انتخاب کنید تا همهٔ هزینه‌های بانکی را شما بپردازید.');
 await p.fill('[data-pol="processing"][data-lg="en"]','International transfers usually take 1–5 working days.');
 await p.fill('[data-pol="amount_rule"][data-lg="en"]','The full amount shown must arrive in our account.');
 await p.fill('#psAppr','ap@x.com');
 await p.click('#psForm button[type=submit]');await p.waitForTimeout(900);ok(/#\/payments$/.test(p.url()),'settings saved (test mode)');
 await hash('#/payments/settings',900);await p.check('input[name=psMode][value=live]');await p.click('#psForm button[type=submit]');await p.waitForTimeout(600);
 const liveErr=await err('#psErr');ok(/company legal name/.test(liveErr)&&/remove sample/.test(liveErr)&&/tax setting confirmed/.test(liveErr),'live refused while incomplete: '+liveErr.slice(0,90));
 // 3. owner: start a bank payment
 await as('o@x.com');await hash('#/billing',1200);
 ok(await p.locator('#bankPay').isVisible()&&/TEST/.test(await p.locator('.paytest').innerText()),'bank form with TEST banner');
 await p.selectOption('#bpCountry','DE');await p.waitForTimeout(200);
 ok(/not set up yet/.test(await p.locator('#bpCountryMsg').innerText())&&await p.locator('#bpGo').isHidden(),'unlisted country → contact support');
 await p.selectOption('#bpCountry','IR');await p.waitForTimeout(200);ok(/contact support/i.test(await p.locator('#bpCountryMsg').innerText()),'contact-only country → contact support');
 await p.selectOption('#bpCountry','AF');await p.waitForTimeout(200);
 ok(JSON.stringify(await p.$$eval('#bpCur option',o=>o.map(x=>x.value)))==='["USD"]','AF: only USD offered');
 await p.selectOption('#bpPlan','pro');await p.selectOption('#bpMonths','3');await p.waitForTimeout(200);
 const sum=await p.locator('#bpSum').innerText();ok(/57\.00 USD/.test(sum)&&/Not added/.test(sum),'summary 3×19 = 57 USD, tax not added (not confirmed)');
 await p.fill('#bpCompany','');await p.click('#bpGo');await p.waitForTimeout(300);ok(/Company name and address/.test(await err('#bpErr')),'company required');
 await p.fill('#bpCompany','Kabul Star Travel Ltd');await p.fill('#bpAddress','Shar-e-Naw, Kabul');await p.fill('#bpTaxId','AF-1002003');
 await p.click('#bpGo');await p.waitForTimeout(1000);
 const ref=(await p.locator('.payref').first().innerText()).trim();ok(/^FH-[2-9A-HJ-NP-Z]{8}$/.test(ref),'unique reference '+ref);
 const req=await p.locator('#bankPay').innerText();
 ok(/57\.00 USD/.test(req)&&/3 months/.test(req)&&/Afghanistan/.test(req)&&/IBAN/.test(req)&&/SWIFT/.test(req),'total, duration, country, IBAN and SWIFT shown');
 ok(/Sample bank details for testing/.test(req),'sample bank clearly marked');
 ok(/OUR/.test(req)&&/1–5 working days/.test(req)&&/full amount/.test(req),'fee, processing time and amount policies shown');
 await p.screenshot({path:'pay-request.png',fullPage:true});
 // report payment with receipt — must NOT activate
 await p.fill('#prPayer','Kabul Star Travel');await p.fill('#prAmt','57');await p.setInputFiles('#prFile',{name:'receipt.png',mimeType:'image/png',buffer:PNG});
 await p.click('#prGo');await p.waitForTimeout(1000);
 ok(/Awaiting verification/.test(await p.locator('#bankPay').innerText()),'status: Awaiting verification');
 const st1=await subOf('Kabul Star Travel');
 ok(!st1.paid_until&&st1.trial_ends,'receipt + report did not activate anything');
 // 4. other owner cannot see it
 await as('o2@x.com');await hash('#/billing',1200);ok(!/FH-/.test(await p.locator('#view').innerText()),'other business owner does not see the payment');
 const peek=await p.evaluate(async()=>{const {data}=await window.__sb.from('payment_requests').select('*');return data.length});ok(peek===0,'other owner reads 0 payment rows');
 const steal=await p.evaluate(async r=>{try{const all=JSON.parse(sessionStorage.getItem('mockdb')).db.payment_requests;const {error}=await window.__sb.rpc('falak_billing_decide',{rid:all[0].id,act:'approve',p_ref:r,p_amount:57,p_currency:'USD',p_bank_ref:'X',p_date:'2026-11-08'});return error?error.message:'approved!'}catch(e){return e.message}},ref);
 ok(/payment approver/.test(steal),'customer cannot approve: '+steal);
 // 5. approver verifies
 await as('ap@x.com');await p.waitForTimeout(800);await hash('#/payments',1200);
 ok(await p.locator('#sideFoot a[href="#/payments"]').count()===1,'approver sees Payment approvals link');
 await p.locator('tr.click',{hasText:ref}).click();await p.waitForTimeout(900);
 const det=await p.locator('#payDetail').innerText();ok(/Kabul Star Travel/.test(det)&&/AF-1002003/.test(det)&&/57\.00 USD/.test(det),'detail: business, tax id, amount');
 const [pop]=await Promise.all([p.waitForEvent('popup',{timeout:4000}).catch(()=>null),p.click('#pdRcpt')]);ok(!!pop,'approver opens private receipt');if(pop)await pop.close();
 const decide=async(act,o)=>{await p.fill('#pdAmt',o.amt??'');await p.fill('#pdCur',o.cur||'USD');await p.fill('#pdBankRef',o.br||'');await p.fill('#pdRef',o.ref??ref);await p.fill('#pdNote',o.note||'');
   await p.click(`#pdForm [data-act=${act}]`);await p.waitForTimeout(300);if(act==='approve'&&await p.locator('#mYes').count()){await p.click('#mYes')}await p.waitForTimeout(900)};
 await decide('approve',{amt:'57',br:'BR-1',ref:'FH-WRONG00'});ok(/does not match/.test(await err('#pdErr')),'wrong reference refused (wrong business protection)');
 await decide('approve',{amt:'1700',cur:'TRY',br:'BR-1'});ok(/arrived in TRY/.test(await err('#pdErr')),'wrong currency refused');
 await decide('receive',{amt:'30',br:'BR-1'});ok(/Part payment received/.test(await p.locator('#payDetail').innerText()),'part payment recorded');
 await decide('approve',{amt:''});ok(/Only 30\.00 USD of 57\.00 USD/.test(await err('#pdErr')),'cannot approve a part payment');
 await decide('receive',{amt:'27',br:'br-1'});ok(/already used/.test(await err('#pdErr')),'same bank reference refused');
 await decide('approve',{amt:'30',br:'BR-2'});
 const det2=await p.locator('#payDetail').innerText();ok(/Approved/.test(det2)&&/TEST: subscription not changed/.test(det2)&&/Overpaid/.test(det2)&&/3\.00 USD/.test(det2),'approved (test), overpayment 3.00 USD flagged');
 const again=await p.evaluate(async r=>{try{const all=JSON.parse(sessionStorage.getItem('mockdb')).db.payment_requests;const {error}=await window.__sb.rpc('falak_billing_decide',{rid:all[0].id,act:'approve',p_ref:r,p_amount:57,p_currency:'USD',p_bank_ref:'BR-3',p_date:'2026-11-08'});return error?error.message:'again!'}catch(e){return e.message}},ref);
 ok(/already approved/.test(again),'duplicate approval refused');
 await p.fill('#pdInvNo','GIB2026000123');await p.fill('#pdInvDate','2026-11-10');await p.click('#pdInv button');await p.waitForTimeout(700);
 ok(/GIB2026000123/.test(await p.inputValue('#pdInvNo')),'official invoice number recorded');
 await p.screenshot({path:'pay-approve.png',fullPage:true});
 const st2=await subOf('Kabul Star Travel');
 ok(st2&&!st2.paid_until,'TEST approval did not change the subscription');
 const st3=await p.evaluate(async()=>{const {error}=await window.__sb.rpc('falak_billing_save',{v:{mode:'off'}});return error?error.message:'saved!'});ok(/super admin/.test(st3),'approver cannot change settings');
 // 6. customer: confirmation (not a tax invoice)
 await as('o@x.com');await hash('#/billing',1200);
 ok(await p.locator('#bankPay #bpForm').count()===1,'customer can start a new payment after approval');
 await p.click('a[href^="#/billing/confirm/"]');await p.waitForTimeout(900);
 const cf=await p.locator('.payconf').innerText();ok(/This is not a tax invoice/.test(cf)&&/GIB2026000123/.test(cf)&&/TEST/.test(cf)&&/60\.00 USD/.test(cf),'payment confirmation separate from tax invoice, shows invoice number');
 // 7. LIVE (inside the test mock only): complete settings
 await as('falaktravelagency11@gmail.com');await hash('#/payments/settings',900);
 await p.check('input[name=psMode][value=live]');
 const vals={legal_name:'Example Travel Agency Ltd (mock)',address:'Istanbul (mock)',tax_no:'0000000000',tax_office:'Mock'};for(const [k,v] of Object.entries(vals))await p.fill(`[data-co="${k}"]`,v);
 for(let i=0;i<2;i++){const r=p.locator('#psBanks .bankrow').nth(i);await r.locator('[data-bk=test]').uncheck();await r.locator('[data-bk=bank_name]').fill('Mock Bank '+i);}
 await p.check('#psTaxOk');await p.click('#psAddTax');const tr=p.locator('#psTax .ctyrow').last();await tr.locator('[data-tc]').selectOption('TR');await tr.locator('[data-tl]').fill('KDV');await tr.locator('[data-tr]').fill('20');
 await p.click('#psForm button[type=submit]');await p.waitForTimeout(900);ok(/#\/payments$/.test(p.url())&&/live/.test(await p.locator('.paymode').innerText()),'live mode saved when complete');
 await as('o@x.com');await hash('#/billing',1200);ok(await p.locator('.paytest').count()===0,'no TEST banner in live');
 await p.selectOption('#bpCountry','TR');await p.waitForTimeout(150);await p.selectOption('#bpCur','TRY');await p.selectOption('#bpPlan','pro');await p.selectOption('#bpMonths','1');await p.waitForTimeout(200);
 ok(await p.locator('#bpTaxOfficeBox').isVisible()&&/129\.80 TRY/.test(await p.locator('#bpSum').innerText())&&/778\.80 TRY/.test(await p.locator('#bpSum').innerText()),'TR: KDV 20% added (accountant-confirmed setting)');
 await p.fill('#bpCompany','Kabul Star Travel Ltd');await p.fill('#bpAddress','Istanbul');await p.click('#bpGo');await p.waitForTimeout(1000);
 p.once('dialog',d=>d.accept());await p.click('#prCancel');await p.waitForTimeout(300);if(await p.locator('#mYes').count())await p.click('#mYes');await p.waitForTimeout(900);
 ok(await p.locator('#bpForm').count()===1,'customer cancelled the TRY payment');
 const pay=async(country,cur,plan,months)=>{await hash('#/billing',1100);await p.selectOption('#bpCountry',country);await p.waitForTimeout(150);await p.selectOption('#bpCur',cur);await p.selectOption('#bpPlan',plan);await p.selectOption('#bpMonths',String(months));
   await p.fill('#bpCompany','Kabul Star Travel Ltd');await p.fill('#bpAddress','Kabul');await p.click('#bpGo');await p.waitForTimeout(1000);const r=(await p.locator('.payref').first().innerText()).trim();await p.click('#prGo');await p.waitForTimeout(900);return r};
 const approve=async(r,amtv,br)=>{await as('ap@x.com');await p.waitForTimeout(500);await hash('#/payments',1100);await p.locator('tr.click',{hasText:r}).click();await p.waitForTimeout(800);await decide('approve',{amt:amtv,br,ref:r});return p.locator('#payDetail').innerText()};
 const r1=await pay('AF','USD','pro',1);let d1=await approve(r1,'19','LIVE-1');
 const sub1=await subOf('Kabul Star Travel');const trialEnd=sub1.trial_ends.slice(0,10);
 ok(/Approved/.test(d1)&&!/TEST/.test(d1)&&sub1.paid_until&&new RegExp(trialEnd.split('-').reverse().join('/')).test(d1),'live approval during trial: starts when trial ends, ends '+sub1.paid_until);
 await as('o@x.com');await hash('#/billing',1100);ok(/paid until/i.test(await p.locator('#view').innerText())&&/Active/.test(await p.locator('#view').innerText()),'customer sees Active, paid until date');
 // renewal (early payment)
 const r2=await pay('AF','USD','pro',3);await approve(r2,'57','LIVE-2');
 const sub2=await subOf('Kabul Star Travel');
 const exp=(()=>{const t=new Date(sub1.paid_until+'T00:00:00Z');t.setUTCDate(t.getUTCDate()+1);t.setUTCMonth(t.getUTCMonth()+3);t.setUTCDate(t.getUTCDate()-1);return t.toISOString().slice(0,10)})();
 ok(sub2.paid_until===exp,'renewal added after current paid time: '+sub1.paid_until+' → '+sub2.paid_until);
 // rejection
 await as('o@x.com');const r3=await pay('AF','USD','basic',1);
 await as('ap@x.com');await p.waitForTimeout(500);await hash('#/payments',1100);await p.locator('tr.click',{hasText:r3}).click();await p.waitForTimeout(800);
 await decide('reject',{ref:r3,note:''});ok(/reason/.test(await err('#pdErr')),'reject needs a reason');
 await decide('reject',{ref:r3,note:'No money arrived after 14 days'});ok(/Rejected/.test(await p.locator('#payDetail').innerText()),'payment rejected');
 const sub3=await subOf('Kabul Star Travel');
 ok(sub3.plan==='pro'&&sub3.paid_until===sub2.paid_until,'rejection changed nothing');
 const ledger=await p.evaluate(()=>JSON.parse(sessionStorage.getItem('mockdb')).db.payments.filter(x=>x.request_id).map(x=>x.amount+' '+x.currency+' '+x.paid_from+'→'+x.paid_until+' by '+x.created_by));
 ok(ledger.length===2&&ledger.every(x=>/by ap@x\.com/.test(x)),'ledger records amount, currency, dates and approver: '+ledger.join(' | '));
 // 8. languages and right-to-left
 await as('o@x.com');await pay('AF','USD','pro',1);await hash('#/billing',1100);
 for(const [lg,re] of [['fa',/پرداخت با انتقال بانکی/],['ps',/د بانکي لېږد له لارې تادیه/],['tr',/Banka havalesiyle öde/]]){await p.selectOption('#langSide',lg);await p.waitForTimeout(600);ok(re.test(await p.locator('#bankPay').innerText()),'billing in '+lg)}
 await p.selectOption('#langSide','fa');await p.waitForTimeout(600);
 ok(await p.evaluate(()=>document.documentElement.dir)==='rtl'&&await p.locator('.payref').getAttribute('dir')==='ltr','RTL page, reference kept left-to-right');
 ok(/OUR را انتخاب/.test(await p.locator('.paypol').innerText()),'Dari policy text shown to Dari reader');
 await p.screenshot({path:'pay-fa.png',fullPage:true});
 await p.selectOption('#langSide','en');await p.waitForTimeout(400);
 await p.setViewportSize({width:390,height:844});await p.waitForTimeout(400);await p.screenshot({path:'pay-mobile.png',fullPage:true});
 ok(await p.evaluate(()=>document.documentElement.scrollWidth<=392),'no sideways scrolling on a phone');
 ok(!errs.length,'no page errors '+errs.join(' | '));
 await b.close();
})();
