-- Q2 (read-only): every line in a public falak_* function that compares falak_role(...)
-- with = / <> / IN / NOT IN, and whether the same function first refuses a missing role.
-- falak_role(...) returns NULL for a non-member; "IF NULL <> 'owner' THEN raise" does NOT raise.
select p.oid::regprocedure as function, l.n as line_no, btrim(l.txt) as line,
       p.prosrc ~* 'falak_role\s*\([^)]*\)\s+is\s+null\s+then\s+(raise|return)'
         or l.txt ~* 'coalesce\s*\(\s*public\.falak_role'            as missing_role_refused_first
from pg_proc p
cross join lateral regexp_split_to_table(p.prosrc, E'\n') with ordinality as l(txt, n)
where p.pronamespace = 'public'::regnamespace and p.proname like 'falak\_%'
  and l.txt ~* 'falak_role\s*\([^)]*\)\s*(<>|!=|=|not\s+in|in)\s'
order by 1, 2;
