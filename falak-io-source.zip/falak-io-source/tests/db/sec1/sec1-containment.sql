-- OPTIONAL temporary containment (only if Step 12 cannot be reviewed quickly).
-- Blocks ALL callers of the two installed functions, including legitimate owners and admins.
revoke execute on function public.falak_choose_free(uuid)        from anon, authenticated, public;
revoke execute on function public.falak_request_plan(uuid, text) from anon, authenticated, public;
-- To end containment (after Step 12 is in place), give back exactly what Q1 showed before. With the source defaults:
--   grant execute on function public.falak_choose_free(uuid)        to authenticated;
--   grant execute on function public.falak_request_plan(uuid, text) to authenticated;
--   (and to anon only if Q1 showed anon_can_execute = true before containment; after Step 12 anon is refused inside the function anyway)
