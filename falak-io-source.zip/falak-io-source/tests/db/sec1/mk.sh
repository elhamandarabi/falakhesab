#!/bin/bash
# usage: mk.sh dbname file1.sql file2.sql ...   (fresh DB with the Supabase stand-in, then each file; stops at the first error)
set -e
db=$1; shift
psql -h /home/claude/pg -p 5544 -U postgres -qc "drop database if exists $db" -c "create database $db" 2>/dev/null
psql -h /home/claude/pg -p 5544 -U postgres -q -v ON_ERROR_STOP=1 -d $db -f /home/claude/fh/sec1/shim.sql >/dev/null 2>&1
for f in "$@"; do psql -h /home/claude/pg -p 5544 -U postgres -q -v ON_ERROR_STOP=1 -d $db -f "$f" >/dev/null 2>/tmp/claude-0/mk.err || { echo "FAILED in $f:"; grep -i error /tmp/claude-0/mk.err; exit 1; }; done
echo "built $db"
