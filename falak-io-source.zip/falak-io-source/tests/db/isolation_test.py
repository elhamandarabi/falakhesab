# Company isolation & role tests against database/supabase-setup.sql on local PostgreSQL with a Supabase stand-in.
import psycopg2, json, uuid, sys
DSN="host=/home/claude/pg port=5544 user=postgres dbname=fh"
su=psycopg2.connect(DSN); su.autocommit=True
U={}
def user(key,email,meta=None):
    i=str(uuid.uuid4()); U[key]=(i,email)
    su.cursor().execute("insert into auth.users(id,email,raw_user_meta_data) values(%s,%s,%s)",(i,email,json.dumps(meta or {})))
for k,e in [('super','falaktravelagency11@gmail.com'),('a_owner','owner@a.test'),('a_admin','admin@a.test'),('a_user','user@a.test'),('a_viewer','viewer@a.test'),
            ('a_removed','removed@a.test'),('b_owner','owner@b.test'),('stranger','stranger@x.test'),('a_mfa','mfa@a.test')]:
    user(k,e)
results=[]
def run(actor,sql,args=(),aal='aal1'):
    """run as an actor: None = anon; returns (ok, rows or error)"""
    c=psycopg2.connect(DSN); cur=c.cursor()
    try:
        if actor is None:
            cur.execute("set role anon")
        else:
            i,e=U[actor]
            cur.execute("select set_config('request.jwt.claim.sub',%s,false), set_config('request.jwt.claims',%s,false)",(i,json.dumps({'sub':i,'email':e,'aal':aal,'role':'authenticated'})))
            cur.execute("set role authenticated")
        cur.execute(sql,args)
        rows=cur.fetchall() if cur.description else cur.rowcount
        c.commit(); return True,rows
    except Exception as ex:
        c.rollback(); return False,str(ex).split('\n')[0]
    finally: c.close()
def check(area,actor,what,expect,res,detail=''):
    ok,val=res
    if expect=='deny': passed=(not ok) or val in (0,[],[(None,)],[(0,)])
    elif expect=='allow': passed=ok and val not in (0,[])
    else: passed=expect(ok,val)
    results.append((area,actor or 'anon',what,'PASS' if passed else 'FAIL',str(val)[:110]))
# ---- set up two companies (as their owners, so triggers run as in production) ----
A=str(uuid.uuid4()); B=str(uuid.uuid4())
print(run('a_owner',"insert into businesses(id,name,owner) values(%s,'Company A',%s)",(A,U['a_owner'][0])))
print(run('b_owner',"insert into businesses(id,name,owner) values(%s,'Company B',%s)",(B,U['b_owner'][0])))
for k,role,tabs in [('a_admin','admin','{}'),('a_user','user','{receipt}'),('a_viewer','viewer','{}'),('a_removed','viewer','{}'),('a_mfa','admin','{}')]:
    print(k,run('a_owner',"insert into members(business_id,email,role,tabs) values(%s,%s,%s,%s) returning id",(A,U[k][1],role,tabs)))
RA={}
def rec(owner,biz,typ,data):
    i=str(uuid.uuid4()); r=run(owner,"insert into records(id,business_id,type,data) values(%s,%s,%s,%s) returning id",(i,biz,typ,json.dumps(data))); assert r[0],r; return i
RA['cust']=rec('a_owner',A,'customer',{'name':'Passenger Ali','phone':'+90 555','notes':'passport P123'})
RA['inv']=rec('a_owner',A,'salesinvoice',{'date':'2026-11-01','customer':RA['cust'],'lines':[{'desc':'x','qty':1,'price':100}],'shareToken':'a'*32})
RA['slip']=rec('a_owner',A,'payslip',{'date':'2026-11-01','employee':'E','gross':5000})
RA['tk']=rec('a_owner',A,'ticket',{'date':'2026-11-01','passenger':'P','sell':500,'cost':400})
RB=rec('b_owner',B,'customer',{'name':'B secret'})
su.cursor().execute("insert into storage.objects(bucket_id,name) values('attachments',%s)",(f"{A}/{RA['inv']}/invoice.pdf",))
su.cursor().execute("insert into auth.mfa_factors(user_id,status) values(%s,'verified')",(U['a_mfa'][0],))
# remove the 'removed' user
print('remove',run('a_owner',"delete from members where business_id=%s and email=%s",(A,U['a_removed'][1])))
# ---- 1. outsiders: B owner, a stranger, a removed user, anonymous ----
for actor in ['b_owner','stranger','a_removed',None]:
    S='isolation'
    check(S,actor,'read A records',          'deny',run(actor,"select id from records where business_id=%s",(A,)))
    check(S,actor,'read A business row',     'deny',run(actor,"select id from businesses where id=%s",(A,)))
    check(S,actor,'read A members',          'deny',run(actor,"select email from members where business_id=%s",(A,)))
    check(S,actor,'read A history',          'deny',run(actor,"select id from history where business_id=%s",(A,)))
    check(S,actor,'read A subscription',     'deny',run(actor,"select plan from subscriptions where business_id=%s",(A,)))
    check(S,actor,'read A payments',         'deny',run(actor,"select id from payments where business_id=%s",(A,)))
    check(S,actor,'insert record into A',    'deny',run(actor,"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'customer','{}')",(A,)))
    check(S,actor,'update A invoice',        'deny',run(actor,"update records set data='{}' where id=%s",(RA['inv'],)))
    check(S,actor,'delete A invoice',        'deny',run(actor,"delete from records where id=%s",(RA['inv'],)))
    check(S,actor,'add self as member of A', 'deny',run(actor,"insert into members(business_id,email,role) values(%s,'evil@x.test','owner')",(A,)))
    check(S,actor,'rename business A',       'deny',run(actor,"update businesses set name='hacked' where id=%s",(A,)))
    check(S,actor,'read A attachment (storage)','deny',run(actor,"select name from storage.objects where name like %s",(A+'/%',)))
    check(S,actor,'upload into A attachments','deny',run(actor,"insert into storage.objects(bucket_id,name) values('attachments',%s)",(f"{A}/{RA['inv']}/x.pdf",)))
    check(S,actor,'rpc falak_plan_state(A)', 'deny',run(actor,"select falak_plan_state(%s)",(A,)))
    check(S,actor,'rpc falak_choose_free(A)','deny',run(actor,"select falak_choose_free(%s)",(A,)))
    check(S,actor,'rpc falak_request_plan(A)','deny',run(actor,"select falak_request_plan(%s,'pro')",(A,)))
    check(S,actor,'rpc falak_mark_paid(A)',  'deny',run(actor,"select falak_mark_paid(%s,'pro',12,0,'USD','x')",(A,)))
    check(S,actor,'rpc falak_admin_set(A)',  'deny',run(actor,"select falak_admin_set(%s,'complimentary','true')",(A,)))
    check(S,actor,'rpc falak_billing_create(A)','deny',run(actor,"select falak_billing_create(%s,'pro',1,'TR','USD','{\"company\":\"x\",\"address\":\"y\"}')",(A,)))
    check(S,actor,'read chat_log',           'deny',run(actor,"select id from chat_log"))
    check(S,actor,'read billing_config',     'deny',run(actor,"select id from billing_config"))
    check(S,actor,'write app_config (prices)','deny',run(actor,"update app_config set value='{}' where key='plans'"))
# B owner tries to move its own record into A, or reuse A's id
check('isolation','b_owner','move own record into A','deny',run('b_owner',"update records set business_id=%s where id=%s",(A,RB)))
check('isolation','b_owner','upsert onto A record id','deny',run('b_owner',"insert into records(id,business_id,type,data) values(%s,%s,'customer','{}') on conflict (id) do update set data=excluded.data",(RA['inv'],B)))
check('isolation','b_owner','give own business to A owner','deny',run('b_owner',"update businesses set owner=%s where id=%s",(U['a_owner'][0],B)))
# public share links
check('public link','anon','short/guessed token','deny',run(None,"select falak_shared_doc('aaaa')"))
ok,v=run(None,"select falak_shared_doc(%s)",('a'*32,))
check('public link','anon','valid token returns invoice','allow',(ok,v))
check('public link','anon','valid token also returns customer notes + all business settings',lambda ok,v: True,(ok,v),)
results[-1]=('public link','anon','shared invoice JSON includes customer record (notes: passport P123) and business.settings','FINDING' if 'passport' in str(v) else 'ok',str(v)[:110])
# ---- 2. roles inside A ----
R='roles'
check(R,'a_viewer','read A records','allow',run('a_viewer',"select id from records where business_id=%s",(A,)))
check(R,'a_viewer','write a record','deny',run('a_viewer',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'customer','{}')",(A,)))
check(R,'a_user','write a receipt (allowed tab)','allow',run('a_user',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'receipt','{\"date\":\"2026-11-02\"}') returning id",(A,)))
check(R,'a_user','write a sales invoice (tab not allowed)','deny',run('a_user',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'salesinvoice','{}')",(A,)))
check(R,'a_user','READ sales invoices (tab not allowed)','deny',run('a_user',"select id from records where business_id=%s and type='salesinvoice'",(A,)))
check(R,'a_user','READ customers (tab not allowed)','deny',run('a_user',"select data from records where business_id=%s and type='customer'",(A,)))
check(R,'a_user','read payslips','deny',run('a_user',"select id from records where business_id=%s and type='payslip'",(A,)))
check(R,'a_user','give self more tabs','deny',run('a_user',"update members set tabs='{salesinvoice,payslip}' where business_id=%s and email=%s",(A,U['a_user'][1])))
check(R,'a_user','give self admin role','deny',run('a_user',"update members set role='admin' where business_id=%s and email=%s",(A,U['a_user'][1])))
check(R,'a_admin','add a second owner','deny',run('a_admin',"insert into members(business_id,email,role) values(%s,'x2@x.test','owner')",(A,)))
check(R,'a_admin','demote the owner','deny',run('a_admin',"update members set role='viewer' where business_id=%s and role='owner'",(A,)))
check(R,'a_admin','remove the owner','deny',run('a_admin',"delete from members where business_id=%s and role='owner'",(A,)))
check(R,'a_admin','read history','allow',run('a_admin',"select id from history where business_id=%s",(A,)))
check(R,'a_viewer','read history','deny',run('a_viewer',"select id from history where business_id=%s",(A,)))
check(R,'a_user','read subscription/payments','deny',run('a_user',"select plan from subscriptions where business_id=%s",(A,)))
# MFA: enrolled user signed in with password only (aal1)
check('mfa','a_mfa','read records at aal1 (factor enrolled)','deny',run('a_mfa',"select id from records where business_id=%s",(A,),aal='aal1'))
check('mfa','a_mfa','read records at aal2','allow',run('a_mfa',"select id from records where business_id=%s",(A,),aal='aal2'))
check('mfa','a_mfa','call falak_plan_state at aal1','deny',run('a_mfa',"select falak_plan_state(%s)",(A,),aal='aal1'))
check('mfa','a_mfa','call falak_request_plan at aal1','deny',run('a_mfa',"select falak_request_plan(%s,'basic')",(A,),aal='aal1'))
su.cursor().execute("insert into auth.mfa_factors(user_id,status) values(%s,'verified')",(U['super'][0],))
check('mfa','super','super admin falak_admin_set at aal1 (factor enrolled)','deny',run('super',"select falak_admin_set(%s,'note','x')",(A,),aal='aal1'))
check('mfa','super','super admin falak_mark_paid at aal1 (factor enrolled)','deny',run('super',"select falak_mark_paid(%s,'basic',1,0,'USD','test')",(A,),aal='aal1'))
# ---- 3. plan rules in the database ----
P='plans'
su.cursor().execute("update subscriptions set plan='free', trial_ends=null, paid_until=null, complimentary=false where business_id=%s",(A,))
check(P,'a_owner','Free: add ticket','deny',run('a_owner',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'ticket','{}')",(A,)))
check(P,'a_owner','Free: edit ticket','deny',run('a_owner',"update records set data=data||'{\"sell\":1}' where id=%s",(RA['tk'],)))
check(P,'a_owner','Free: DELETE ticket (published: read-only)','deny',run('a_owner',"delete from records where id=%s returning id",(RA['tk'],)))
su.cursor().execute("update subscriptions set plan='basic', trial_ends=now()-interval '1 day', paid_until=null where business_id=%s",(A,))
check(P,'a_owner','Expired: read books','allow',run('a_owner',"select id from records where business_id=%s",(A,)))
check(P,'a_owner','Expired: add record','deny',run('a_owner',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'customer','{}')",(A,)))
check(P,'a_owner','Expired: delete record','deny',run('a_owner',"delete from records where id=%s",(RA['cust'],)))
check(P,'a_owner','Expired: add user','deny',run('a_owner',"insert into members(business_id,email,role) values(%s,'new@a.test','viewer')",(A,)))
check(P,'a_owner','Expired: remove user','allow',run('a_owner',"delete from members where business_id=%s and email=%s returning id",(A,U['a_viewer'][1])))
check(P,'a_owner','Expired: upload attachment','deny',run('a_owner',"insert into storage.objects(bucket_id,name) values('attachments',%s)",(f"{A}/{RA['inv']}/y.pdf",)))
su.cursor().execute("update subscriptions set plan='basic', paid_until=current_date+30 where business_id=%s",(A,))
n=run('a_owner',"select count(*) from members where business_id=%s",(A,))[1][0][0]
check(P,'a_owner',f'Basic (3 users): add user #{n+1}','deny' if n>=3 else 'allow',run('a_owner',"insert into members(business_id,email,role) values(%s,'n4@a.test','viewer') returning id",(A,)))
# ---- 4. ledger guards ----
L='ledger'
check(L,'a_owner','unbalanced journal','deny',run('a_owner',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'journal','{\"date\":\"2026-11-03\",\"lines\":[{\"debit\":100},{\"credit\":90}]}')",(A,)))
check(L,'a_owner','sales invoice with text as price','deny',run('a_owner',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'salesinvoice','{\"date\":\"2026-11-03\",\"lines\":[{\"qty\":\"abc\",\"price\":\"<img src=x onerror=alert(1)>\"}]}')",(A,)))
check(L,'a_owner','receipt with no date','deny',run('a_owner',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'receipt','{\"lines\":[{\"amount\":50}]}')",(A,)))
su.cursor().execute("update businesses set settings=settings||'{\"lockDate\":\"2026-10-31\"}' where id=%s",(A,))
check(L,'a_owner','insert before lock date','deny',run('a_owner',"insert into records(id,business_id,type,data) values(gen_random_uuid(),%s,'receipt','{\"date\":\"2026-10-01\"}')",(A,)))
check(L,'a_admin','admin moves the lock date back','deny',run('a_admin',"update businesses set settings=settings||'{\"lockDate\":\"2020-01-01\"}' where id=%s",(A,)))
# ---- 5. billing (manual, live today) ----
B1='billing'
r1=run('super',"select falak_mark_paid(%s,'pro',1,19,'USD','bank ref 123')",(A,),aal='aal2'); r2=run('super',"select falak_mark_paid(%s,'pro',1,19,'USD','bank ref 123')",(A,),aal='aal2')
check(B1,'super','same transfer recorded twice extends twice', lambda ok,v: False if (r1[0] and r2[0]) else True,(True,[r1[1],r2[1]]))
for r in results: print('\t'.join(r))
print('PASS',sum(r[3]=='PASS' for r in results),'FAIL',sum(r[3]=='FAIL' for r in results),'FINDING',sum(r[3]=='FINDING' for r in results))
