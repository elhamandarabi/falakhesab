import psycopg2,json,uuid
exec(open('isolation_test.py').read().split('# ---- set up two companies')[0])
# fresh companies
A=str(uuid.uuid4()); B=str(uuid.uuid4())
run('a_owner',"insert into businesses(id,name,owner) values(%s,'Company A2',%s)",(A,U['a_owner'][0]))
run('b_owner',"insert into businesses(id,name,owner) values(%s,'Company B2 (one user)',%s)",(B,U['b_owner'][0]))
run('a_owner',"insert into members(business_id,email,role) values(%s,%s,'viewer')",(A,U['a_removed'][1]))
run('a_owner',"delete from members where business_id=%s and email=%s",(A,U['a_removed'][1]))
su.cursor().execute("update subscriptions set plan='pro', paid_until=current_date+200, trial_ends=null, complimentary=false where business_id=%s",(B,))
su.cursor().execute("update businesses set slug='company-b' where id=%s",(B,))
def show(t,r): print(t,'->',r)
show('stranger: falak_choose_free(B, one-user business, paid Pro)',run('stranger',"select falak_choose_free(%s)",(B,)))
su_c=su.cursor(); su_c.execute("select plan,paid_until,note from subscriptions where business_id=%s",(B,)); show('  B subscription now',su_c.fetchall())
su_c.execute("select slug from businesses where id=%s",(B,)); show('  B company address now',su_c.fetchall())
show('removed user: falak_request_plan(A)',run('a_removed',"select falak_request_plan(%s,'basic')",(A,)))
su_c.execute("select requested_plan from subscriptions where business_id=%s",(A,)); show('  A requested_plan now',su_c.fetchall())
# Step 11 in TEST mode
cfg={"mode":"test","currencies":["USD"],"durations":[1,12],"prices":{"basic":{"USD":9},"pro":{"USD":19}},"countries":{"TR":{"status":"supported","currencies":["USD"]}},
     "banks":[{"currency":"USD","bank":"Sample Bank (TEST)","iban":"TEST","test":True}],"tax":{"confirmed":False},"approvers":[]}
su_c.execute("update billing_config set value=%s where id=1",(json.dumps(cfg),))
show('stranger: falak_billing_create for A (test mode)',run('stranger',"select (falak_billing_create(%s,'pro',1,'TR','USD','{\"company\":\"x\",\"address\":\"y\"}')).ref",(A,)))
ok,v=run('a_owner',"select (falak_billing_create(%s,'pro',1,'TR','USD','{\"company\":\"A\",\"address\":\"Istanbul\"}')).id",(A,)); show('owner A creates request',(ok,v))
rid=v[0][0] if ok else None
show('removed user: falak_billing_cancel(A request)',run('a_removed',"select falak_billing_cancel(%s)",(rid,)))
su_c.execute("select status from payment_requests where id=%s",(rid,)); show('  request status now',su_c.fetchall())
su_c.execute("select id,ref from payment_requests where business_id=%s",(A,)); rid2,ref2=su_c.fetchall()[0]
show('removed user: falak_billing_report on that request',run('a_removed',"select (falak_billing_report(%s,'{\"payer\":\"x\"}',null)).status",(rid2,)))
show('stranger: falak_billing_cancel on that request',run('stranger',"select falak_billing_cancel(%s)",(rid2,)))
su_c.execute("select status from payment_requests where id=%s",(rid2,)); show('  status now',su_c.fetchall())
# exactly-once approval (test mode; super is approver)
ok,v=run('a_owner',"select (falak_billing_create(%s,'pro',1,'TR','USD','{\"company\":\"A\",\"address\":\"Istanbul\"}')).id",(A,)); rid3=v[0][0]
su_c.execute("select ref,total from payment_requests where id=%s",(rid3,)); ref3,tot=su_c.fetchall()[0]
show('approver: wrong currency',run('super',"select (falak_billing_decide(%s,'approve',%s,%s,'EUR','BR1',current_date,null)).status",(rid3,ref3,tot),aal='aal2'))
show('approver: wrong reference typed',run('super',"select (falak_billing_decide(%s,'approve','FH-WRONG',%s,'USD','BR1',current_date,null)).status",(rid3,tot),aal='aal2'))
show('approver: part payment then approve',run('super',"select (falak_billing_decide(%s,'approve',%s,5,'USD','BR1',current_date,null)).status",(rid3,ref3),aal='aal2'))
show('approver: record part payment',run('super',"select (falak_billing_decide(%s,'receive',%s,5,'USD','BR1',current_date,null)).status",(rid3,ref3),aal='aal2'))
show('approver: same bank ref again',run('super',"select (falak_billing_decide(%s,'receive',%s,14,'USD','br1',current_date,null)).status",(rid3,ref3),aal='aal2'))
show('approver: rest + approve',run('super',"select (falak_billing_decide(%s,'approve',%s,14,'USD','BR2',current_date,null)).status",(rid3,ref3),aal='aal2'))
show('approver: approve again',run('super',"select (falak_billing_decide(%s,'approve',%s,0,'USD','',null,null)).status",(rid3,ref3),aal='aal2'))
show('approver at aal1 (factor enrolled): decide',run('super',"select (falak_billing_decide(%s,'reject',%s,0,'USD','',null,'x')).status",(rid3,ref3),aal='aal1'))
